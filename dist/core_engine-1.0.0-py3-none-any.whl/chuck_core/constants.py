se_user = 'Admin'
se_pass = 'P@ssword'

# Mapping of room ID from webex to room ID in Schneider electric
# key - room id from webex
# value - room id from SE
room_mapping = {
    'test' : '01/Server 1/Cisco Hackathon/Team 4/Conference Room A/Values',
    '' : '',
    '' : ''
}